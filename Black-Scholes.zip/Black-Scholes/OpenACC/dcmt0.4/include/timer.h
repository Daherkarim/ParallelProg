#ifndef _mfh_timer_h
#define _mfh_timer_h

void
init_timer ();

double
get_seconds ();

#endif /* _mfh_timer_h */
